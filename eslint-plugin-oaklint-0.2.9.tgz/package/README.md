# oaklint (`eslint-plugin-oaklint`)

[![npm version](https://img.shields.io/npm/v/eslint-plugin-oaklint.svg)](https://www.npmjs.com/package/eslint-plugin-oaklint)
[![npm downloads](https://img.shields.io/npm/dm/eslint-plugin-oaklint.svg)](https://www.npmjs.com/package/eslint-plugin-oaklint)
[![codecov](https://codecov.io/gh/omaralikhn/oaklint-ts/branch/main/graph/badge.svg)](https://codecov.io/gh/omaralikhn/oaklint-ts)
[![license](https://img.shields.io/badge/license-PolyForm%20Strict%201.0.0-blue.svg)](https://github.com/omaralikhn/oaklint-ts/blob/main/LICENSE)

Opinionated oak lint rules for TypeScript, shipped as an ESLint plugin. The same plugin runs on [Oxlint](https://oxc.rs) via its ESLint-compatible plugin API, so one artifact covers both linters.

The npm package is `eslint-plugin-oaklint`. It is the TypeScript companion to [oak](https://github.com/omaralikhn/oaklint) (the Rust/Python linter published to PyPI as `oaklint`, command `oak`).

## What it enforces

oak's opinionated rules split two ways against TypeScript. This plugin builds the rules that have no mature off-the-shelf equivalent. For the parts the TS ecosystem already solves, it points you at the standard rule to enable yourself rather than duplicating it.

### Rules this plugin adds

Codes share the family-letter scheme of [oak](https://github.com/omaralikhn/oaklint): `F` formatting, `N` naming, `D` design, `T` testing. Codes are the public API and are never renumbered.

| Code | Rule | Fixable | Enforces | Why |
|------|------|---------|----------|-----|
| [OAKF04](docs/rules/comment-shape.md) | `oaklint/comment-shape` | no | Prose comments are a sentence-case `NOTE:`/`TODO:`/`XXX:` note ending with a period. | The prefix states intent - explain, defer, or warn - and the sentence shape keeps a comment a complete thought rather than a fragment where stale notes hide. |
| [OAKF05](docs/rules/comment-alignment.md) | `oaklint/comment-alignment` | no | Continuation lines of a multi-line comment align under the header's first word. | A shared left edge makes a wrapped comment read as one paragraph, so the eye tracks it as a single thought instead of stray fragments. |
| [OAKN04](docs/rules/action-verb-names.md) | `oaklint/action-verb-names` | no | Function and method names lead with an approved action verb. | A function does something, so a verb-led name states the action at the call site; a bare noun reads as an accessor and hides whether it computes, mutates, or fetches. |
| [OAKD02](docs/rules/member-ordering.md) | `oaklint/member-ordering` | no | Public class members sit above the private and protected members of the same class. | Reading top to bottom, a class should open with its public surface and descend into private mechanics, so you learn what it does before how. |
| [OAKD03](docs/rules/dependency-ordering.md) | `oaklint/dependency-ordering` | no | A definition sits below the later siblings in its scope that reference it. | Reading top to bottom, callers should sit above the helpers they lean on, so each scope opens with its entry points and descends into the machinery. |
| [OAKD04](docs/rules/no-tuple-return.md) | `oaklint/no-tuple-return` | no | A function returning several positional values uses a named type, not a multi-element array. | An array names each value only by position, so a reordered or same-typed pair is destructured wrong with nothing to complain until the bad value surfaces later. |
| [OAKD05](docs/rules/no-empty-string-sentinel.md) | `oaklint/no-empty-string-sentinel` | no | An absent value is `undefined`, not an empty string standing in for it. | An empty string is a present value, so it sails through every presence check and gets used as real data; `undefined` is the one unambiguous marker of absence. |
| [OAKD06](docs/rules/no-record-object-return.md) | `oaklint/no-record-object-return` | no | A function returning a fixed-shape record uses a named type, not a bare object literal. | A bare object literal has no declared shape, so a misspelled or renamed key yields `undefined` at runtime far from the function that owns the shape instead of a compile error at the call site. |
| [OAKT04](docs/rules/no-mock-call-assertion.md) | `oaklint/no-mock-call-assertion` | no | A test asserts observable behaviour, not how a mock was called (`toHaveBeenCalledWith` and its family). | Asserting on the calls made couples the test to the code's current shape, so it breaks on a behaviour-preserving refactor and passes for a wrong result reached the expected way. |

### Rules to use off the shelf

oak covers several things the TS ecosystem already solves well, and a few Python-derived rules whose intent does not transfer to TypeScript. Enable the standard rule directly rather than reaching for this plugin.

#### Replacements for an oak rule

Each oak rule below maps to a standard rule that already enforces the same intent, so this plugin does not reimplement it.

| oak code | Use instead | Why off the shelf | Where |
|----------|-------------|-------------------|-------|
| OAKF01 blank line after a block / OAKF02 blank line before a return | `@stylistic/padding-line-between-statements` with `{ blankLine: "always", prev: "block-like", next: "*" }` and `{ blankLine: "always", prev: "*", next: "return" }` | The stylistic rule owns statement-padding and auto-fixes it, so `eslint --fix` inserts the blank line. Its `block-like` group covers `if`/`for`/`while`/`try`/`switch`, and it never pads before `else`/`catch`/`finally`, so it stays compatible with Prettier's `} else {`. | [`padding-line-between-statements`](https://eslint.style/rules/padding-line-between-statements) |
| OAKF01 blank line between class members | `@stylistic/lines-between-class-members` with `'always'` and `{ exceptAfterSingleLine: true }` | The stylistic rule is the class-scope analogue of the statement padding above, and auto-fixes it. `exceptAfterSingleLine` keeps a run of single-line fields tight while still requiring a blank line after any multi-line member. Prettier leaves adjacent members untouched, so there is no clash. | [`lines-between-class-members`](https://eslint.style/rules/lines-between-class-members) |
| OAKF04 companion - space after `//` | `@stylistic/spaced-comment` with `'always'` and `{ markers: ["/"] }` | Prettier never touches a comment's internals, so `//text` stays cramped. The stylistic rule requires the space and auto-fixes it, and the `/` marker keeps `///` TS reference directives valid. | [`spaced-comment`](https://eslint.style/rules/spaced-comment) |
| OAKN01 import alias | `no-useless-rename` | It flags the pointless self-alias `import { foo as foo }`. A genuine rename (`foo as bar`) is idiomatic in TS - a default import has no canonical name and collisions need aliases - so the greppability rationale does not hold. | [`no-useless-rename`](https://eslint.org/docs/latest/rules/no-useless-rename) |
| OAKN03 single-character names | `id-length` with `{ "min": 2 }` | Core ESLint already flags short identifiers, with the same intent (a single letter carries no meaning and cannot be searched for). | [`id-length`](https://eslint.org/docs/latest/rules/id-length) |
| OAKT02 throw asserted with no message | `jest/require-to-throw-message` or `vitest/require-to-throw-message` | Those rules already require an argument to `toThrow()`. The stricter oak intent - reject a substring match and assert the full message - would flag `toThrow("msg")`, the canonical throw-assertion in both runners, with no ergonomic replacement. | [jest/require-to-throw-message](https://github.com/jest-community/eslint-plugin-jest/blob/main/docs/rules/require-to-throw-message.md) |
| OAKT03 conditionals in tests | `jest/no-conditional-in-test` or `vitest/no-conditional-tests` | The test-framework plugins own this check and track the frameworks' own APIs, so a branch that silently skips an assertion is caught without a duplicate rule. | [eslint-plugin-jest](https://github.com/jest-community/eslint-plugin-jest/blob/main/docs/rules/no-conditional-in-test.md), [@vitest/eslint-plugin](https://github.com/vitest-dev/eslint-plugin-vitest) |
| OAKS01 / OAKS02 module line limits | `max-lines` with a per-glob test override | Core ESLint measures file length with the exact knobs oak uses (skip blanks/comments, a larger budget for test files). | [`max-lines`](https://eslint.org/docs/latest/rules/max-lines) |
| ban `any` | `@typescript-eslint/no-explicit-any` | The mature rule covers the annotation, with `no-restricted-syntax` for `as any`. | [`no-explicit-any`](https://typescript-eslint.io/rules/no-explicit-any/) |
| ban the `!` non-null assertion | `@typescript-eslint/no-non-null-assertion` | The `!` operator is exactly what that rule flags, with no oak-specific carve-out to add. | [`no-non-null-assertion`](https://typescript-eslint.io/rules/no-non-null-assertion/) |
| ban `enum` (prefer union literals) | `no-restricted-syntax` with the `TSEnumDeclaration` selector | typescript-eslint deliberately declined a dedicated `no-enum` rule and documents this selector as the answer, so a one-line config covers it. | [`no-restricted-syntax`](https://eslint.org/docs/latest/rules/no-restricted-syntax) |
| require `readonly` on unchanging fields | `@typescript-eslint/prefer-readonly` + `parameter-properties` | These cover private fields and constructor parameters; a broader version needs reassignment dataflow and adds little. | [`prefer-readonly`](https://typescript-eslint.io/rules/prefer-readonly/) |

#### Additional rules worth enabling

These have no oak equivalent - they are off-the-shelf rules that push the same readability, simplicity, and performance goals oak stands for, so oaklint's own [`eslint.config.dogfood.js`](https://github.com/omaralikhn/oaklint-ts/blob/main/eslint.config.dogfood.js) turns them on.

| Goal | Use | Why | Where |
|------|-----|-----|-------|
| one binding per declaration | `@stylistic/one-var-declaration-per-line` with `'always'` | Prettier keeps `let a, b, c` on one line. The stylistic rule puts each binding on its own line, so a reader scans one name per line and diffs stay narrow. | [`one-var-declaration-per-line`](https://eslint.style/rules/one-var-declaration-per-line) |
| one statement per line | `@stylistic/max-statements-per-line` with `{ max: 1 }` | A compressed `doA(); doB()` line hides how many things happen on it. The rule makes it an error before Prettier ever reformats. | [`max-statements-per-line`](https://eslint.style/rules/max-statements-per-line) |
| cap the line at Prettier's width | `max-len` with `{ code: 120, ignoreStrings: true, ignoreTemplateLiterals: true, ignoreUrls: true, ignoreRegExpLiterals: true }` | Prettier wraps code at `printWidth` but leaves a long string, URL, or regex literal on one line. The ignore flags exempt exactly those literals, so the cap fails only on reflowable code Prettier could not wrap, never on a literal it deliberately kept whole. Set `code` to match your Prettier `printWidth`. | [`max-len`](https://eslint.org/docs/latest/rules/max-len) |
| always brace a block body | `curly` with `'all'` | Prettier keeps a braceless `if (ready) go()` on one line, so a later-added second statement silently falls outside the branch. Core `curly` requires the braces and auto-fixes them, closing the goto-fail gap. | [`curly`](https://eslint.org/docs/latest/rules/curly) |
| flat early-return style | `no-else-return` with `{ allowElseIf: false }` and `no-lonely-if` | Dropping the `else` after a returning branch and collapsing a lone nested `if` de-indents the rest, so a function reads as a sequence of guards rather than a pyramid. | [`no-else-return`](https://eslint.org/docs/latest/rules/no-else-return), [`no-lonely-if`](https://eslint.org/docs/latest/rules/no-lonely-if) |
| one obvious form for common idioms | `object-shorthand` (`'always'`), `no-unneeded-ternary`, `prefer-template`, `prefer-const`, `@typescript-eslint/dot-notation` with `{ allowIndexSignaturePropertyAccess: true }` (base `dot-notation` off) | These strip redundant punctuation and pick a single canonical form: `{ x }` over `{ x: x }`, a plain value over `? true : false`, a template literal over `+` concatenation, `const` over never-reassigned `let`, and `obj.key` over `obj['key']`. All auto-fix. Use the typescript-eslint variant, not base `dot-notation`: with `noPropertyAccessFromIndexSignature` on, TypeScript mandates bracket access on an index signature, and `allowIndexSignaturePropertyAccess` leaves that access alone where the base rule would autofix it to dot access and break the build. | [`object-shorthand`](https://eslint.org/docs/latest/rules/object-shorthand), [`@typescript-eslint/dot-notation`](https://typescript-eslint.io/rules/dot-notation/) |
| idiomatic type-aware simplifications | `@typescript-eslint/prefer-optional-chain`, `prefer-includes`, `prefer-string-starts-ends-with` | These read plainer than their long forms - `a?.b?.c` over an `&&` chain, `.includes(x)` over `.indexOf(x) !== -1`, `.startsWith(x)` over `.indexOf(x) === 0` - and are in typescript-eslint's recommended type-checked set. | [`prefer-optional-chain`](https://typescript-eslint.io/rules/prefer-optional-chain/) |
| flat is better than nested | `max-depth` with `{ max: 3 }` | Capping block nesting forces a tangled branch to move into its own function, so no single scope buries logic four levels deep. | [`max-depth`](https://eslint.org/docs/latest/rules/max-depth) |
| say the comparison plainly | `eqeqeq` (`'always'`), `no-nested-ternary`, `no-implicit-coercion` | `===` states an exact comparison with no hidden coercion, a nested ternary is unpacked into an `if`/`else` or lookup, and `Number(x)` / `Boolean(x)` name the conversion that `+x` / `!!x` hide. | [`eqeqeq`](https://eslint.org/docs/latest/rules/eqeqeq), [`no-nested-ternary`](https://eslint.org/docs/latest/rules/no-nested-ternary), [`no-implicit-coercion`](https://eslint.org/docs/latest/rules/no-implicit-coercion) |
| drop what the compiler already knows | `@typescript-eslint/no-inferrable-types`, `no-unnecessary-boolean-literal-compare` | A `const count = 5` needs no `: number`, and a boolean is already a condition, so `isReady === true` is just `isReady`. Both auto-fix. | [`no-inferrable-types`](https://typescript-eslint.io/rules/no-inferrable-types/) |
| reject genuinely confusing forms | `@typescript-eslint/no-confusing-void-expression`, `no-confusing-non-null-assertion` | Assigning or returning a `void` expression reads as if it produced a value, and a `!` next to an operator reads as part of a comparison; both are flagged so the intent stays unambiguous. | [`no-confusing-void-expression`](https://typescript-eslint.io/rules/no-confusing-void-expression/) |
| avoid serialized async and runtime recompilation | `no-await-in-loop`, `prefer-regex-literals` with `{ disallowRedundantWrapping: true }` | `await` in a loop runs requests one at a time when `Promise.all` could run them together, and `new RegExp("...")` recompiles a fixed pattern on every call where a `/.../` literal compiles once. Add an inline disable for `no-await-in-loop` where serialization is intentional (rate limiting). | [`no-await-in-loop`](https://eslint.org/docs/latest/rules/no-await-in-loop), [`prefer-regex-literals`](https://eslint.org/docs/latest/rules/prefer-regex-literals) |
| avoid accidentally-quadratic lookups | `unicorn/prefer-set-has`, `unicorn/prefer-regexp-test` (from [`eslint-plugin-unicorn`](https://github.com/sindresorhus/eslint-plugin-unicorn)) | An array reached only for `.includes()` membership is O(n) per lookup, so a lookup inside a loop is O(n²) - a `Set` keeps it linear. `RegExp#test` returns the boolean that `String#match` builds a whole result array for. | [`prefer-set-has`](https://github.com/sindresorhus/eslint-plugin-unicorn/blob/main/docs/rules/prefer-set-has.md), [`prefer-regexp-test`](https://github.com/sindresorhus/eslint-plugin-unicorn/blob/main/docs/rules/prefer-regexp-test.md) |

For a worked example of the strictest config - this plugin's own rules plus every off-the-shelf rule above wired in - see oaklint's own [`eslint.config.dogfood.js`](https://github.com/omaralikhn/oaklint-ts/blob/main/eslint.config.dogfood.js), which is the config the plugin lints itself with.

### Unused CSS classes: a companion CI pass, not an ESLint rule

ESLint sees TypeScript, not the CSS a project ships alongside it, so a class defined in a stylesheet that no `className` ever references is invisible to every rule here. That dead-CSS check belongs in a separate CI pass rather than a lint rule.

For a project using plain global CSS with free-form `className` strings, run [PurgeCSS](https://purgecss.com) in report mode over the stylesheets with the source as the content globs, and treat the rejected list as an advisory report. Keep it out of the pass/fail gate: PurgeCSS matches class-name strings in source, so any class applied at runtime by a library (`highlight.js` writes `.hljs-*` onto tokens it emits) or matched off an emitted HTML tag (a `.markdown h2` descendant rule, a bare `kbd`) or composed from a bounded set (`` `bubble ${kind}` ``, `` `diff-${type}` ``) reads as unused when it is not. Those are false positives, so the list is a lead for a human, never a verdict.

```js
// NOTE: A CI script, not an ESLint rule - ESLint cannot see the CSS.
//       PurgeCSS reports classes in the stylesheets that never appear
//       as a class-name string in source. Advisory only: exit 0 and let
//       a human read the list.
import { PurgeCSS } from 'purgecss'

const results = await new PurgeCSS().purge({
  content: ['src/**/*.{ts,tsx,html}', 'index.html'],
  css: ['src/styles/*.css'],
  // NOTE: Classes composed at runtime never appear as a whole literal, so
  //       PurgeCSS cannot see them and would wrongly flag them - safelist them.
  safelist: ['good', 'warn', 'bad', 'is-open', 'is-copied'],
  rejected: true,
})

for (const { file, rejected = [] } of results) {
  // NOTE: A .hljs-* class is written by highlight.js at runtime and a
  //       `.markdown h2` rule matches an emitted tag, not a source string -
  //       both are false positives, so drop them before printing the report.
  const orphans = rejected.filter(
    (selector) => !selector.startsWith('.hljs') && !selector.startsWith('.markdown '),
  )
  if (orphans.length > 0) {
    console.log(file, orphans)
  }
}
```

A project on CSS Modules (`import styles from './x.module.css'`, `styles.foo` access) gets both directions for free instead: a typo'd `styles.buton` becomes a type error under [`typescript-plugin-css-modules`](https://github.com/mrmckeb/typescript-plugin-css-modules), and [`check-unused-css`](https://github.com/malinindev/check-unused-css) reports the unused classes. Neither works for free-form global `className` strings, which is why the PurgeCSS report above is the only option there.

### Caveat when enabling the off-the-shelf `@typescript-eslint/no-unnecessary-condition`

This is a gotcha in the off-the-shelf `@typescript-eslint/no-unnecessary-condition` rule, not in any rule this plugin ships. It bites when you turn that rule on with `noUncheckedIndexedAccess` off in `tsconfig.json` (the default).

With `noUncheckedIndexedAccess` off, an index access like `arr[0]` or `record[key]` is typed as always present, so `@typescript-eslint/no-unnecessary-condition` reports `arr[0]?.x` and `if (!record[key])` as redundant. The type is lying: an empty array or an unknown key yields `undefined` at runtime, so deleting the `?.` or the guard crashes there.

```ts
function firstName(names: string[]): string | undefined {
  // NOTE: no-unnecessary-condition flags `?.` as redundant, because the type
  //       says `names[0]` is always a string - but an empty array makes it
  //       `undefined` at runtime, so removing the `?.` throws here.
  return names[0]?.toUpperCase()
}
```

When this fires and the value truly can be absent at runtime, the fix is to turn on `noUncheckedIndexedAccess` (so the type admits `undefined`) or to keep the check explicit with `arr.length` or the `in` operator - not to remove the optional chain the rule flagged.

## Install

```bash
npm install --save-dev eslint-plugin-oaklint
```

Peer dependencies: `eslint >= 9`, `typescript >= 5`.

## Use

Flat config (`eslint.config.js`):

```js
import oaklint from 'eslint-plugin-oaklint'

export default [
  oaklint.configs.recommended,
]
```

Or enable individual rules:

```js
import oaklint from 'eslint-plugin-oaklint'

export default [
  {
    plugins: { oaklint },
    rules: {
      'oaklint/comment-shape': 'error',
    },
  },
]
```

## Develop

```bash
npm install
npm run check     # format:check, lint, typecheck, build, test with coverage
```

`npm run check:ci` additionally runs `knip`. Knip's native binding has no Termux/arm64 build, so `check` keeps it out and CI runs it on Linux.

The plugin dogfoods itself: `npm run dogfood` points the built plugin at its own source via `eslint.config.dogfood.js`. It runs last in `check`, after format, lint, typecheck, build, and tests have passed, so a broken rule fails the dogfood step without masking the standard checks.

### Release

Releases are tag-driven. Bump `version` in `package.json`, commit it, then push a matching `v` tag:

```bash
git tag v0.2.0
git push origin v0.2.0
```

The release workflow runs the full check, verifies the tag matches `package.json`, and publishes to npm with provenance. It reads an `NPM_TOKEN` repository secret (a granular access token with publish rights). A `workflow_dispatch` run checks and builds without publishing.

### Version notes

* TypeScript is pinned to `~6.0.3`, not 7.x. `typescript-eslint@8` requires `typescript < 6.1`, and the TS7 native compiler has no Android/arm64 binary, so type-aware linting breaks on it.

The rule modules are dogfooded against [`eslint-plugin-eslint-plugin`](https://github.com/eslint-community/eslint-plugin-eslint-plugin) so a malformed `meta`, `messageId`, or schema is caught at lint time.
